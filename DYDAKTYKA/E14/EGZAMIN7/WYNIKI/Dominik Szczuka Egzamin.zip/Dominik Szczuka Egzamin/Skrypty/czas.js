<script type="text/javascript">


function oblicz(){

var liczba1=eval(prompt("Podaj pierwszą liczbę."));
var liczba2=eval(prompt("Podaj drugą liczbę."));

var a=liczba1+liczba2;
var b=liczba1-liczba2;
var c=liczba1*liczba2;
var d=liczba1/liczba2;

alert("Wynik dodawania to:"+a+"_Wynik odejmowania to:"+b+"_Wynik mnożenia to:"+c+"_Wynik dzielenia to:"+d);






}



</script>
