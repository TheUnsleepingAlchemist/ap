<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link href="skrypty/szkola.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function raport()
   
    </script>
</head>
<body>
   <div id="calosc">
   <div id="logo"></div>
 <div id="gora">
      <img class="logo" src="grafika/logo.jpg">
   <br><center>
   Menu:<a class="kolor" href="stronaglowna .php">Home</a>
 <a class="kolor" href="galeria.php">Galeria</a>  
  <a class="kolor"  href="autor.php">Autor</a>
  </center>
  </div>
 <div id="strona">
 Galeria:

     
    </div>
     <div id="prawa">
      <div id="dane">
    <strong><a class="kolor"  href="Dane osobowe.html">Dane Osobowe:</a></strong>
 <ul>
	<li><a class="kolor"  href="raport.html">Uczniowie klasami</a></li>
	</ul>
 
 
 
     </div>
     <div id="link">
      <b>Ciekawe linki:</b>
       <ul>
      <li><a href="https://www.wp.pl/" target="blank">wp.pl</a></li>
      <li><a href="https://www.interia.pl/" target="blank">interia.pl</a></li>
      </ul>
      </div>
         <div id="motto">
              <strong>MOTTO:</strong>
              <blockquote>„Zawsze można być lepszym niż się jest”.</blockquote>  
             
              </div>
           
          </div>
 
    </div>
 </body>
</html>