# Sprawdzian "Test"

**Data**: 17-12-2018

*Budowa strony internetowej która ma na celu pełnienie roli egzaminu online, ma ona obliczać punkty zdobyte przez użytkownika oraz powinna ona zawierać różnorodne funkcje HTML, CSS wraz z podstawowymi funkcjami kodu JavaScript.*

## Dodatkowe informacje
Temat Pracy: "Podstawy kryptowalut oraz technologi Blockchain"
Ilość Pytań: 5

## Szybki Checklist

- [x] Bezużyteczny README.md w folderze
- [x] Bezsensowny git init w folderze
- [x] Zastosowanie wyboru *radio*
- [x] Zastosowanie listy *select*
- [x] Zastosowanie wybory *checkbox*
- [X] Kalkulator punków jako skrypt
- [x] Zastosowanie obrazka
- [x] Formatowanie CSS
- [x] Zestaw pięciu pytań
- [ ] Relatywność strony
- [x] Brak responsywności strony

## Zawartość Sprawdzianu

- Dołączanie skryptu do strony html
- Prosty skrypt JavaScript
- Załączanie obrazów (local)
- Formatowanie CSS (Czcionka, Kolory, Marginesy etc...)
- Bezsensowny git włożony w folder
- Bezużyteczny README.md w folderze

Wykonano przez Jakub Olan
