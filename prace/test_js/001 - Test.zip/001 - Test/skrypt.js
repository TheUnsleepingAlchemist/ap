function kalk() {
  punkty = 0;

  // HACK: Pytanie #1

  if (document.getElementById("1A").checked) punkty;

  if (document.getElementById("1B").checked) punkty;

  if (document.getElementById("1C").checked) punkty++;

  // HACK: Pytanie #2

  if (
    document.getElementById("2A").checked &&
    document.getElementById("2B").checked &&
    document.getElementById("2C").checked
  ) punkty--;

  if (document.getElementById("2B").checked && document.getElementById("2C").checked
) punkty++;

  if (document.getElementById("2A").checked) punkty;
  if (document.getElementById("2B").checked) punkty;
  if (document.getElementById("2C").checked) punkty;

  // HACK: Pytanie #3

  if (document.getElementById("Q3").value === "T") punkty++;

  // HACK: Pytanie #4

  if (document.getElementById("4C").checked) punkty++;
  else punkty;

  // HACK: Pytanie #5

  if (document.getElementById("5A").checked) punkty++;
  else punkty;

  // HACK: Kalkulator, suma punktów

  document.getElementById("punkty").innerHTML = punkty;
}
